const ninetySix = function() {
	return {
		about: "",
		className: "ninetySix",
		init: function() {},
		revert: function() {},
		visible: function() {},
	}
}();