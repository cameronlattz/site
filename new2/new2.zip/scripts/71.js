const seventyOne = function() {
	"using strict";
	let _container = null;
	let _running = false;

	const _init = function(languages) {
        console.log("init 71");
		if (!_running) {
            _running = true;
            _container = document.getElementById("container71");
            _container.classList.add("loading");
            setTimeout(function() {
                _container.classList.remove("loading");
                _container.classList.add("loaded");
                const containers = document.getElementById("contentContainer").children;
                const tvContainers = _container.querySelector("#contentContainerTv").children;
                for (let i = 0; i < containers.length; i++) {
                    tvContainers[i+1].innerHTML = containers[i].innerHTML;
                }
            }, 500);
            _moveNavbar();
		}
    }

	const _moveNavbar = function() {
        const navbar = _container.getElementsByClassName("navbar-container")[0];
		navbar.classList.add("loaded");
    }

    const _revert = function() {
		if (_running) {
            _running = false;
            _container.classList.remove("loaded");
            const navbar = _container.getElementsByClassName("navbar-container")[0];
            navbar.classList.remove("loaded");
            return true;
        }
    }

	return {
		about: "<a href=\"scripts/71.js\">Vanilla JS</a>+<a href=\"styles/71.css\">CSS</a>",
		className: "seventyOne",
		init: _init,
		revert: _revert
	}
}();

/*
three of the washington area youngsters
of the international scout jamboree were honored by being selected for the honor guard on opening day
they were: peter mapes of bethesda, and scott perdy and thomas russell of silver spring

district parents are being urged to take their children for free polio doses today at more than 18 clinics
throughout the city. over 120,000 youngsters (meaning more than 75% of the children between the ages of 2
    months and 10 years) have received the vaccine, but there still are 30,000 who need the immunization.
    although there have been no cases in the past year, officials want to avoid the kind of polio outbreaks
    that victimized children in the years before the vaccine.

we're all in columbia
at the mall in columbia
woodward and lothrop
herschel kohn
airport pants and furniture
peck and peck
and the knick-knack rush
atomic toyshop
miss suzie's casuals
all in columbia
at the mall in columbia
the mall in columbia is open 10am til 9:30pm monday through saturday

well that's all the news for today
tomorrow dick kohl will have a special report
on the rehearsal of a musical production
that opens in wolftrap on august 12th
and dan daniels will be back tomorrow night along with don surriels and the rest of our jolly group
until then, this is julian barber, nbc news. night!
*/