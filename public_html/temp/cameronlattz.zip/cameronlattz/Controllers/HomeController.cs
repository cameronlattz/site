﻿using cameronlattz.Models;
using System.Web.Mvc;

namespace cameronlattz.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var model = new TestModel();
            model.Name = "Cameron";
            return View(model);
        }
    }
}