﻿using System.Web.Optimization;

namespace cameronlattz
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/Styles/css").Include(
                "~/Styles/site.css"
            ));

            bundles.Add(new ScriptBundle("~/Scripts/js").Include(
                "~/Scripts/ready.js",
                "~/Scripts/site.js"
            ));
        }
    }
}