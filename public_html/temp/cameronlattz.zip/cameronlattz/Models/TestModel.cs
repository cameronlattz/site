﻿namespace cameronlattz.Models
{
    public class TestModel
    {
        public string Name { get; set; }
    }
}