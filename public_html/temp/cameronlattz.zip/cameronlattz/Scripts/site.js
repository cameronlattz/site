﻿var site = (function () {
    "use strict"

    return {
        init: function (options) {},
        //init: function (options) {
        //    window.ready(function () {
        //        site.loadAvatar(options.model);
        //    });
        //},
        //loadAvatar: function (model) {
        //    site.notify(model.Name);
        //},

        caution: function (message) {
        // <summary>Creates a yellow popup with a message</summary>
        // <param name="message" type="String">The message to show</param>

        },
        danger: function (message) {
        // <summary>Creates a red popup with a message</summary>
        // <param name="message" type="String">The message to show</param>

        },
        notify: function (message) {
        // <summary>Creates a green popup with a message</summary>
        // <param name="message" type="String">The message to show</param>

        }
    }
})();